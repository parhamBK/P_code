int D(USER *account, char input[100])
{
    int post_id = 0, index = 0, flag = 0, tool_post_id = 0;
    for (int i = 7; input[i] != '\0' && input[i] != '\n'; i++)
    {
        tool_post_id++;
    } /*get the length of the post id*/
    char *post_ID = (char *)malloc((tool_post_id + 1) * sizeof(char));
    for (int i = 7; input[i] != '\0' && input[i] != '\n'; i++)
    {
        post_ID[index] = input[i];
        post_ID[index + 1] = '\0';
        index++;
    } /*fill out the array name*/
    for (int i = 0; i < tool_post_id; i++)
    {
        int new_num = post_ID[i] - 48;
        post_id = post_id + (pow(10, (tool_post_id - i - 1))) * (new_num);
    }
    free(post_ID);
    /*this is a few lines to convert a char from a number to an int*/

    POST *temp_post = account->FirstPost;
    POST *Btemp_post = NULL;  /*previous post*/
    while (temp_post != NULL) /*find post*/
    {
        if (temp_post->post_id == post_id)
        {
            break;
        }
        Btemp_post = temp_post;
        temp_post = temp_post->NextPost;
    }
    if (temp_post == NULL)
    {
        return -1;
    } /*this post does not exi...*/

    if (Btemp_post == NULL) /*delete first post*/
    {
        POST *temp_ad = temp_post->NextPost;
        account->FirstPost = temp_ad;
        temp_post->NextPost = NULL;
        free(temp_post);
        return 0;
    }

    POST *temp_ad = temp_post->NextPost; /*next post*/
    Btemp_post->NextPost = temp_ad;
    temp_post->NextPost = NULL;
    free(temp_post); /*this is a few lines to delete the post*/
    return 0;
}
