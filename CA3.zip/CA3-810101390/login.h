USER *login(USER *head, char input[100])
{
    int tool_name = 0, tool_pasword = 0, index = 0, flag = 0;
    USER *temp = head;
    char *name, *pasword, *TempPtr;
    if (input[5] != ' ')
    {
        return NULL;
    }/*moghavem sazi*/
    if (input[6] == '\0')
    {
        return NULL;
    }/*moghavem sazi*/

    for (int i = 6; input[i] != ' '; i++)
    {
        tool_name++;
    }/*get the length of the name*/
    if (input[tool_name + 6] != ' ')
    {
        return NULL;
    }/*moghavem sazi*/

    if (input[tool_name + 5] == '\0')
    {
        return NULL;
    }/*moghavem sazi*/

    for (int i = tool_name + 7; input[i] != ' ' && input[i] != '\n' && input[i] != '\0'; i++)
    {
        tool_pasword++;
    }/*get the length of the password*/

    name = (char *)malloc((tool_name + 1) * sizeof(char));/*wa add one more for NULL*/
    pasword = (char *)malloc((tool_pasword + 1) * sizeof(char));/*wa add one more for NULL*/

    for (int i = 6; i < tool_name + 6; i++)
    {
        name[index] = input[i];
        name[index + 1] = '\0';
        index++;
    }/*fill out the array name*/
    index = 0;
    for (int i = tool_name + 7; i < tool_name + 7 + tool_pasword; i++)
    {
        pasword[index] = input[i];
        pasword[index + 1] = '\0';
        index++;
    }/*fill out the array password*/

    while (temp != NULL)/*find user*/
    {
        if (!(str(temp->name, name)) && !(str(temp->pasword, pasword)))
        {
            flag++;
            break;
        }
        temp = temp->NextUser;
    }
    free(name);
    free(pasword);
    if (flag != 0)
    {
        return temp;
    }
    else /*if this user does not exist*/
    {
        return NULL;
    }
}