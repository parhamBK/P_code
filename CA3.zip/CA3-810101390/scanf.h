int MyBigFatScanf(char input[100])
{
    char temp;
    int tool = 0;
    for (tool = 0; temp != '\n'; tool++)
    {
        scanf("%c", &temp);/*take one by one from stdin*/
        input[tool] = temp;
    }
    input[tool - 1] = '\0';
    return tool;/*return size of string(witn null)*/
}