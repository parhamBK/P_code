typedef struct user USER;
typedef struct post POST;
typedef struct WhoLike LIKER;
struct user
{
    char *name;
    char *pasword;
    POST *FirstPost;
    USER *NextUser;
};
struct post
{
    char *name;
    int post_id;
    int like;
    char *post;
    POST *NextPost;
    LIKER *FirstLike;
};
struct WhoLike
{
    char *liker;
    LIKER *next;
};

#include "StringCompare.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "GooGle.h"
#include "info.h"
#include "Delete.h"
#include "Likee.h"
#include "post.h"
#include "login.h"
#include "KindOfOrder.h"
#include "signup.h"
#include "scanf.h"

int main()
{
    int KindOfOrder; /*kind of order*/
    USER *account;   /*our user*/

    USER *heap = (USER *)malloc(sizeof(USER)); /*make head of user structe*/
    heap->NextUser = NULL;
    heap->name = (char *)malloc(sizeof(char));
    heap->pasword = (char *)malloc(sizeof(char));
    heap->FirstPost = NULL;
    char input[100];

    while (1)
    {
        printf("\n---------ut tooti---------\n\n");
        int tool = MyBigFatScanf(input);
        KindOfOrder = Koo(input);
        if (KindOfOrder == 0)
        {
            int status = SignUp(heap, input, tool - 1);
            if (status == -1)
            {
                printf("WTF!!!\n");
                continue;
            }
            continue;
        }
        else if (KindOfOrder == 1)
        {
            account = login(heap, input);
            if (account == NULL)
            {
                printf("who?!\n");
                continue;
            }
        }
        else
        {
            printf("what? again\n");
            continue;
        }
        KindOfOrder = 1000; /*enter the sec loop*/
        while (1)
        {
            printf("---------%s--------\n", account->name);
            tool = MyBigFatScanf(input);
            KindOfOrder = Koo(input);
            if (KindOfOrder == 2)
            {
                int status = post(account, input);
                if (status == -1)
                {
                    printf("wrong\n");
                    continue;
                }
            }
            else if (KindOfOrder == 3)
            {
                int status = like(account, input, heap);

                if (status == -1)
                {
                    printf("this user does not exits\n");
                    continue;
                }
                else if (status == -2)
                {
                    printf("this post_id does not exits\n");
                    continue;
                }
                else if (status == -3)
                {
                    printf("again?! nope , you cant\n");
                    continue;
                }
                else if (status == -5)
                {
                    printf("wrong input\n");
                    continue;
                }
            }
            else if (KindOfOrder == 4)
            {
                int status = D(account, input);
                if (status != 0)
                {
                    printf("the operation was unsuccessful, again\n");
                    continue;
                }
            }
            else if (KindOfOrder == 5)
            {
                info(account);
            }
            else if (KindOfOrder == 6)
            {
                int status = GOOGLE(heap, input);
                if (status == -1)
                {
                    printf("the operation was unsuccessful, again\n");
                    continue;
                }
            }
            else if (KindOfOrder == 7)
            {
                break;
            }
            else
            {
                printf("whar are you saying?! again\n");
                continue;
            }
        }
    }
}