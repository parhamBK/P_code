int Koo(char input[100])/*detection of command type and return number*/
{
    char *Order;
    int tool_Order = 0, index = 0;
    for (int i = 0; input[i] != ' ' && i < 100; i++)
    {
        tool_Order++;
    }
    Order = (char *)malloc((tool_Order + 1) * sizeof(char));
    if (Order == NULL)
    {
        printf("please try later\n");
    }
    for (int i = 0; i < tool_Order; i++)
    {
        Order[index] = input[i];
        Order[index + 1] = '\0';
        index++;
    }
    if (!(str(Order, "signup")))
    {
        free(Order);
        return 0;
    }
    else if (!(str(Order, "login")))
    {
        free(Order);
        return 1;
    }
    else if (!(str(Order, "post")))
    {
        free(Order);
        return 2;
    }
    else if (!(str(Order, "like")))
    {
        free(Order);
        return 3;
    }
    else if (!(str(Order, "delete")))
    {
        free(Order);
        return 4;
    }
    else if (!(str(Order, "info")))
    {
        free(Order);
        return 5;
    }
    else if (!(str(Order, "find_user")))
    {
        free(Order);
        return 6;
    }
    else if (!(str(Order, "logout")))
    {
        free(Order);
        return 7;
    }
    else
    {
        free(Order);
        return -1;
    }
}