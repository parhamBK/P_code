int SignUp(USER *head, char input[100], int tool)
{
    int tool_name = 0, tool_pasword = 0, index = 0, space = 0;
    USER *temp = head;
    char *name, *pasword, *TempPtr;
    if (input[6] != ' ')
    {
        return -1;
    } /*moghavem sazi*/
    if (input[7] == '\0')
    {
        return -1;
    } /*moghavem sazi*/

    for (int i = 7; input[i] != ' '; i++)
    {
        tool_name++;
    } /*get the length of the name*/
    if (input[tool_name + 7] != ' ')
    {
        return -1;
    } /*moghavem sazi*/
    if (input[tool_name + 8] == '\0')
    {
        return -1;
    } /*moghavem sazi*/

    for (int i = tool_name + 8; input[i] != ' ' && input[i] != '\0' && input[i] != '\n'; i++)
    {
        tool_pasword++;
    } /*get the length of the password*/

    name = (char *)malloc((tool_name + 1) * sizeof(char));       /*wa add one more for NULL*/
    pasword = (char *)malloc((tool_pasword + 1) * sizeof(char)); /*wa add one more for NULL*/
    for (int i = 7; i < tool_name + 7; i++)
    {
        name[index] = input[i];
        name[index + 1] = '\0';
        index++;
    } /*fill out the array name*/
    index = 0;
    for (int i = tool_name + 8; i < tool_name + 8 + tool_pasword; i++)
    {
        pasword[index] = input[i];
        pasword[index + 1] = '\0';
        index++;
    } /*fill out the array password*/

    while (temp->NextUser != NULL) /*if the desired name is not allowed*/
    {
        if (!(str(temp->name, name)) || (!(str("signup", name)) || !(str("login", name)) || !(str("logout", name)) || !(str("post", name)) || !(str("like", name)) || !(str("delete", name)) || !(str("info", name)) || !(str("find_user", name))))
        {
            return -1;
        }
        temp = temp->NextUser; /*find next user*/
    }
    if (!(str(temp->name, name)) || (!(str("signup", name)) || !(str("login", name)) || !(str("logout", name)) || !(str("post", name)) || !(str("like", name)) || !(str("delete", name)) || !(str("info", name)) || !(str("find_user", name))))
    {
        return -1;
    } /*this is to make the last one count(pay attention to the wording in the while)*/

    temp->NextUser = (USER *)malloc(sizeof(USER)); /*if our name is not a problem, do...*/

    temp = temp->NextUser;
    temp->name = name;
    temp->pasword = pasword;
    temp->NextUser = NULL;
    temp->FirstPost = NULL; /*we write the desired phrase in the top few lines*/
    return 0;
}