int info(USER *account)
{
    printf("name: %s\n", account->name);
    printf("password: %s\n", account->pasword);
    POST *temp = account->FirstPost;
    if (temp == NULL)
    {
        printf("\nno post here\n");
        return 0;
    }

    while (temp != NULL)
    {
        printf("user: %s\n", temp->name);
        printf("post_id: %d\n", temp->post_id);
        printf("like: %d\n", temp->like);
        printf("post: %s\n", temp->post);
        temp = temp->NextPost;
    }
    return 0;
}