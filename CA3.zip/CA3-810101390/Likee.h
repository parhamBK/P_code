int like(USER *account, char input[100], USER *head)
{
    if (input[4] != ' ')
    {
        return -5;
    } /*moghavem sazi*/
    if (input[5] == '\0')
    {
        return -5;
    } /*moghavem sazi*/

    int fl = 0;
    int index = 0;
    int tool_name = 0;
    int post_id = 0;
    for (int i = 5; input[i] != ' '; i++)
    {
        tool_name++;
    } /*get the length of the name*/
    if (input[tool_name + 5] != ' ')
    {
        return -5;
    } /*moghavem sazi*/
    if (input[tool_name + 6] == '\0')
    {
        return -5;
    }                                                            /*moghavem sazi*/
    char *name = (char *)malloc((tool_name + 1) * sizeof(char)); /*wa add one more for NULL*/
    for (int i = 5; i < tool_name + 5; i++)
    {
        name[index] = input[i];
        name[index + 1] = '\0';
        index++;
    } /*fill out the array name*/
      /*-----------------*/
    int tool_post_id = 0;
    for (int i = tool_name + 6; input[i] != '\0' && input[i] != '\n'; i++)
    {
        tool_post_id++;
    }
    char *post_ID = (char *)malloc((tool_post_id + 1) * sizeof(char));
    index = 0;
    for (int i = tool_name + 6; input[i] != '\0' && input[i] != '\n'; i++)
    {
        post_ID[index] = input[i];
        post_ID[index + 1] = '\0';
        index++;
    }
    for (int i = 0; i < tool_post_id; i++)
    {
        int new_num = post_ID[i] - 48;
        post_id = post_id + (pow(10, (tool_post_id - i - 1))) * (new_num);
    }
    free(post_ID);
    /*this is a few lines to convert a char from a number to an int*/

    USER *temp_user = head;
    while (temp_user != NULL) /*find user*/
    {
        if (!(str(temp_user->name, name)))
        {
            break;
        }
        temp_user = temp_user->NextUser;
    }
    free(name);
    if (temp_user == NULL)
    {
        return -1;
    } /*this user does not exist*/

    POST *temp_post = temp_user->FirstPost;
    while (temp_post != NULL) /*find post*/
    {
        if (temp_post->post_id == post_id)
        {
            break;
        }
        temp_post = temp_post->NextPost;
    }
    if (temp_post == NULL)
    {
        return -2;
    } /*this user does not exist*/

    LIKER *temp_like = temp_post->FirstLike;
    LIKER *Btemp_like;
    while (temp_like != NULL) /*the user has not liked this post before*/
    {
        if (!(str(temp_like->liker, account->name)))
        {
            return -3;
        }
        temp_like = temp_like->next;
    }

    temp_post->like = temp_post->like + 1;

    temp_like = temp_post->FirstLike;
    while (temp_like != NULL)
    {
        Btemp_like = temp_like;
        fl++;
        temp_like = temp_like->next;
    } /*add this user to wholike*/

    if (fl == 0)
    {
        temp_post->FirstLike = (LIKER *)malloc(sizeof(LIKER));
        temp_like = temp_post->FirstLike;
        temp_like->liker = account->name;
        temp_like->next = NULL;
        return 0;
    } /*if was first like*/

    Btemp_like->next = (LIKER *)malloc(sizeof(LIKER));
    temp_like = Btemp_like->next;

    temp_like->liker = account->name;
    temp_like->next = NULL;
    return 0;
}