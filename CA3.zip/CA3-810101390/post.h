int post(USER *account, char input[100])
{
    if (input[5] == '\0')
    {
        return -1;
    }/*moghavem sazi*/
    if (input[4] != ' ')
    {
        return -1;
    }/*moghavem sazi*/

    int post_id = 0, tool_post = 0, index = 0, flag = 1;
    POST *temp = account->FirstPost;
    POST *Btemp;
    while (temp != NULL)/*this loop gives a proper post id*/
    {
        post_id++;
        if (temp->post_id != post_id)
        {
            break;
        }
        temp = temp->NextPost;
    }
    post_id++;
    temp = account->FirstPost;
    while (temp != NULL)/*finds the bottom link list of post*/
    {
        Btemp = temp;
        flag++;
        temp = temp->NextPost;
    }
    if (flag == 1)/*if was first post*/
    {
        account->FirstPost = (POST *)malloc(sizeof(POST));
        if (account->FirstPost == NULL)
        {
            printf("please try later\n");
        }
        temp = account->FirstPost;
    }
    else if (flag != 1)
    {
        Btemp->NextPost = (POST *)malloc(sizeof(POST));
        if (Btemp->NextPost == NULL)
        {
            printf("please try later\n");
        }
        temp = Btemp->NextPost;
    }

    for (int i = 5; input[i] != '\0' && input[i] != '\n'; i++)
    {
        tool_post++;
    }/*get the length of the post*/

    char *post = (char *)malloc((tool_post + 1) * sizeof(char));/*wa add one more for NULL*/
    
    for (int i = 5; i < tool_post + 5; i++)
    {
        post[index] = input[i];
        post[index + 1] = '\0';
        index++;
    }/*fill out the array post*/

    temp->FirstLike = NULL;
    temp->like = 0;
    temp->name = account->name;
    temp->post_id = post_id;
    temp->post = post;
    temp->NextPost = NULL; /*we write the desired phrase in the top few lines*/
}