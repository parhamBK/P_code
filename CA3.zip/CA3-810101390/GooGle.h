int GOOGLE(USER *head, char input[100])
{
    int tool_name = 0, post_id, index = 0, flag = 0;
    for (int i = 10; input[i] != '\0' && input[i] != '\n'; i++)
    {
        tool_name++;
    }                                                            /*get the length of the name*/
    char *name = (char *)malloc((tool_name + 1) * sizeof(char)); /*wa add one more for NULL*/
    for (int i = 10; i < tool_name + 11; i++)
    {
        name[index] = input[i];
        name[index + 1] = '\0';
        index++;
    } /*fill out the array name*/
    USER *temp_user = head;
    while (temp_user != NULL) /*find user*/
    {
        if (!(str(temp_user->name, name)))
        {
            break;
        }
        temp_user = temp_user->NextUser;
    }
    free(name);
    if (temp_user == NULL)
    {
        return -1;
    }
    POST *temp_post = temp_user->FirstPost;
    if (temp_post == NULL)
    {
        printf("no post here\n");
        return 0;
    }

    while (temp_post != NULL)
    {
        printf("user: %s\n", temp_post->name);
        printf("post_id: %d\n", temp_post->post_id);
        printf("like: %d\n", temp_post->like);
        printf("post: %s\n", temp_post->post);
        temp_post = temp_post->NextPost;
    }
    return 0;
}