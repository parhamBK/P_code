int str(char *first, char *sec)/*to compare two string*/
{
    int index = 0;
    while ((first[index] != '\0') || (sec[index] != '\0'))
    {
        if (first[index] != sec[index])
        {
            return -1;
        }/*if the char was unequal*/

        index++;
    }
    return 0;
}